# SunSecurityBot — план презентации

Цель презентации: быстро объяснить, какую проблему решает проект, как он работает в реальном GitHub Pull Request, какие технические решения уже реализованы и что можно показать в демо.

Рекомендуемый тайминг: 5-7 минут.

## 1. Проблема

Основная мысль: security-проблемы появляются ещё на этапе Pull Request, но обычное code review не всегда их замечает.

Текст на слайд:

- Уязвимости часто попадают в код до merge
- Ревьюеры фокусируются на логике, а не на security
- SQLi, XSS и секреты легко пропустить вручную
- Чем позже нашли проблему, тем дороже исправление
- Нужен быстрый feedback прямо в PR

Картинка:

- Схема: `Pull Request -> пропущенная уязвимость -> merge -> production risk`
- Или скрин Pull Request с опасной строкой кода
- Можно использовать красные маркеры на строках `cursor.execute(f"...")`, `dangerouslySetInnerHTML`, `API_KEY = "..."`

## 2. Идея решения

Основная мысль: SunSecurityBot встраивается в GitHub workflow и работает как автоматический security reviewer.

Текст на слайд:

- SunSecurityBot — AI security reviewer для GitHub Pull Request
- Бот получает PR diff через webhook
- Анализирует только изменённые строки
- Ищет SQL Injection, XSS и hardcoded secrets
- Оставляет inline-комментарии прямо в GitHub

Картинка:

- Простая схема: `Developer -> GitHub PR -> SunSecurityBot -> Inline comments`
- Иконки: разработчик, GitHub, бот, комментарий
- Скрин или мокап комментария бота в PR

## 3. Сценарий работы в PR

Основная мысль: для разработчика бот выглядит как обычный участник code review.

Текст на слайд:

- Разработчик открывает Pull Request
- GitHub отправляет webhook в SunSecurityBot
- Бот проверяет подпись и забирает diff
- Уязвимости появляются как inline-комментарии
- Summary даёт общую картину по PR
- Разработчик исправляет код до merge

Картинка:

- Timeline из 5-6 шагов
- Лучше всего: реальный скрин GitHub PR до и после комментария
- Можно показать маленький фрагмент diff и рядом комментарий бота

## 4. Ключевые фичи

Основная мысль: это не просто вызов LLM, а полноценный DevSecOps pipeline вокруг Pull Request.

Текст на слайд:

- Inline-комментарии на конкретных строках
- Summary по всем findings
- Анализ только PR diff, а не всего репозитория
- Pre-scan секретов без LLM
- LLM-провайдеры: Polza и OpenRouter
- False-positive filter
- История проверок через SQLite
- Test UI и Console UI для ручной проверки
- Budget limit для контроля расходов на LLM

Картинка:

- Сетка из иконок: GitHub comment, filter, AI, shield, database, dashboard
- Можно сделать блок "не просто LLM" и перечислить слои вокруг модели

## 5. Архитектура пайплайна

Основная мысль: показать техническую цепочку end-to-end.

Текст на слайд:

```text
Webhook Receiver
  -> GitHub Adapter
  -> DiffFilter
  -> Secret Pre-scan
  -> LLMClient
  -> FalsePositiveFilter
  -> CommentPublisher
  -> StateStore
```

Дополнительные подписи:

- FastAPI принимает webhook
- GitHubAdapter забирает PR diff
- DiffFilter оставляет только релевантные added lines
- LLMClient возвращает JSON findings
- CommentPublisher пишет review в PR

Картинка:

- Горизонтальная блок-схема pipeline
- Разными цветами выделить GitHub, analysis core, storage
- Этот слайд должен быть самым "техническим"

## 6. Как снижаем false positives

Основная мысль: главная проблема security-ботов — шум, поэтому проект специально режет нерелевантные срабатывания.

Текст на слайд:

- Не отправляем в LLM весь репозиторий
- Исключаем markdown, картинки, lock-файлы и бинарники
- Проверяем только добавленные строки
- Отбрасываем findings вне PR diff
- Учитываем tests, examples, placeholders
- Env-getters не считаем секретами
- Санитайзеры и параметризованный SQL не флагим как уязвимость

Картинка:

- Воронка: `Raw PR diff -> Filtered diff -> LLM findings -> Final findings`
- Или таблица "шум" / "что делает бот"

## 7. Безопасность и надёжность

Основная мысль: бот сам работает с токенами и кодом, поэтому у него есть защита на уровне webhook, логов, бюджета и публикаций.

Текст на слайд:

- HMAC-проверка GitHub webhook
- Секреты только через env
- Маскирование токенов и API keys в логах
- Дедупликация комментариев в PR
- Budget kill-switch для LLM
- Ошибки GitHub/LLM не валят webhook
- Docker и healthcheck
- SQLite или in-memory state

Картинка:

- Щит вокруг pipeline
- Отдельные бейджи: HMAC, redacted logs, budget limit, dedup, healthcheck

## 8. Демо

Основная мысль: показать рабочий результат, а не только архитектуру.

Текст на слайд:

- Демо PR с намеренной уязвимостью
- Бот получает webhook
- Анализирует diff
- Публикует inline finding
- Добавляет summary по PR

Что показать:

- PR с SQL injection через f-string
- Или PR с hardcoded GitHub/AWS/Stripe token
- Или XSS через `dangerouslySetInnerHTML` / Jinja2 `|safe`

Картинка:

- Реальный скрин GitHub PR
- До/после: слева diff, справа комментарии SunSecurityBot

## 9. Результаты и развитие

Основная мысль: MVP уже закрывает полный цикл, дальше можно расширять классы уязвимостей и UX.

Текст на слайд:

- Реализован end-to-end pipeline для GitHub PR
- Поддержаны SQLi, XSS и hardcoded secrets
- Есть Docker, тесты, e2e fixtures и demo repo
- Есть Test UI, Console UI и история проверок
- Следующее: больше типов уязвимостей
- Следующее: GitLab/Bitbucket
- Следующее: auth для UI
- Следующее: диалог в GitHub replies

Картинка:

- Roadmap из 3-4 шагов
- Можно разделить на "сделано" и "дальше"

## Важная правка по фиче GitHub replies

Диалоговый режим в GitHub replies лучше не заявлять как готовую фичу. В текущем коде есть публикация review comments, summary comments, обновление summary и дедупликация, но нет полноценной обработки ответов пользователя в комментариях.

Формулировка для презентации:

> Сейчас бот автоматически комментирует Pull Request. Следующий шаг развития — диалоговый режим, где разработчик сможет отвечать боту прямо в GitHub comments.

