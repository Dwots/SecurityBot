/* =============================================================
   SunSecurityBot — main deck engine
   - Slide navigation: keys (arrows, space, PgUp/PgDn, Home/End, 1-0), wheel, swipe, dots, buttons
   - On-slide animations: typed text, count-up, tilt-cards, terminal demo
   ============================================================= */
(function () {
  const slides = Array.from(document.querySelectorAll('.slide'));
  const total = slides.length;
  const $cur = document.getElementById('cur');
  const $tot = document.getElementById('total');
  const $progress = document.getElementById('progress');
  const $prev = document.getElementById('prev');
  const $next = document.getElementById('next');
  const $dots = document.getElementById('dotsNav');

  let current = 0;
  let busy = false;

  // ---------- dots nav
  slides.forEach((_, i) => {
    const b = document.createElement('button');
    b.setAttribute('aria-label', 'slide ' + (i + 1));
    b.addEventListener('click', () => goto(i));
    $dots.appendChild(b);
  });
  const dotEls = Array.from($dots.children);

  function setActive(i) {
    slides.forEach((s, idx) => {
      s.classList.toggle('active', idx === i);
      s.classList.toggle('leaving', idx === current && idx !== i);
    });
    dotEls.forEach((d, idx) => d.classList.toggle('active', idx === i));
    const pad = (n) => String(n).padStart(2, '0');
    $cur.textContent = pad(i + 1);
    $tot.textContent = pad(total);
    $progress.style.width = ((i + 1) / total * 100) + '%';
  }

  function goto(i) {
    if (busy) return;
    i = Math.max(0, Math.min(total - 1, i));
    if (i === current) return;
    busy = true;
    const prev = current;
    current = i;
    setActive(i);
    onEnter(i, prev);
    setTimeout(() => { busy = false; }, 700);
  }

  function next() { goto(current + 1); }
  function prev() { goto(current - 1); }

  // ---------- keyboard
  document.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowRight' || e.key === 'PageDown' || e.key === ' ') { e.preventDefault(); next(); }
    else if (e.key === 'ArrowLeft' || e.key === 'PageUp') { e.preventDefault(); prev(); }
    else if (e.key === 'Home') { e.preventDefault(); goto(0); }
    else if (e.key === 'End') { e.preventDefault(); goto(total - 1); }
    else if (/^[0-9]$/.test(e.key)) {
      const n = e.key === '0' ? 9 : parseInt(e.key, 10) - 1;
      if (n < total) goto(n);
    }
  });

  // ---------- wheel
  let wheelLock = false;
  window.addEventListener('wheel', (e) => {
    if (wheelLock) return;
    if (Math.abs(e.deltaY) < 20) return;
    wheelLock = true;
    if (e.deltaY > 0) next(); else prev();
    setTimeout(() => { wheelLock = false; }, 700);
  }, { passive: true });

  // ---------- touch swipe
  let touchY = null, touchX = null;
  window.addEventListener('touchstart', (e) => {
    touchY = e.touches[0].clientY; touchX = e.touches[0].clientX;
  }, { passive: true });
  window.addEventListener('touchend', (e) => {
    if (touchY == null) return;
    const dy = e.changedTouches[0].clientY - touchY;
    const dx = e.changedTouches[0].clientX - touchX;
    if (Math.abs(dy) > 50 && Math.abs(dy) > Math.abs(dx)) {
      if (dy < 0) next(); else prev();
    } else if (Math.abs(dx) > 60) {
      if (dx < 0) next(); else prev();
    }
    touchY = touchX = null;
  });

  if ($next) $next.addEventListener('click', next);
  if ($prev) $prev.addEventListener('click', prev);

  // ---------- 3D tilt cards
  const tiltAll = document.querySelectorAll('.tilt');
  tiltAll.forEach(el => {
    el.addEventListener('mousemove', (e) => {
      const r = el.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width - 0.5;
      const y = (e.clientY - r.top) / r.height - 0.5;
      const rx = (-y * 6).toFixed(2);
      const ry = (x * 8).toFixed(2);
      el.style.transform = `perspective(900px) rotateX(${rx}deg) rotateY(${ry}deg) translateZ(0)`;
    });
    el.addEventListener('mouseleave', () => {
      el.style.transform = '';
    });
  });

  // ---------- typed text on title
  function typeWord(el, text, delay) {
    return new Promise((resolve) => {
      el.textContent = '';
      let i = 0;
      const speed = 75;
      setTimeout(function step() {
        if (i < text.length) {
          el.textContent += text[i++];
          setTimeout(step, speed);
        } else { resolve(); }
      }, delay);
    });
  }

  async function runTitleTyped() {
    const words = document.querySelectorAll('.hero-title .word');
    let delay = 200;
    for (const w of words) {
      const txt = w.getAttribute('data-typed') || '';
      await typeWord(w, txt, delay);
      delay = 60;
    }
  }

  // ---------- count up
  function countUp(el, target, duration = 1200) {
    const start = performance.now();
    const from = 0;
    function step(t) {
      const p = Math.min(1, (t - start) / duration);
      // easeOutCubic
      const e = 1 - Math.pow(1 - p, 3);
      el.textContent = Math.round(from + (target - from) * e);
      if (p < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }

  function animateCountsIn(slide) {
    slide.querySelectorAll('[data-count]').forEach(el => {
      const target = parseFloat(el.getAttribute('data-count'));
      countUp(el, target, 1400);
    });
  }

  // ---------- terminal demo
  const TERM_SCRIPT = [
    { p: '$', t: 'curl -X POST https://sunbot.dev/webhook -H "X-GitHub-Event: pull_request" -d @pr-42.json', d: 30 },
    { o: '⏳ verifying HMAC signature...', cls: 'out', d: 400 },
    { o: '✓ signature OK', cls: 'ok', d: 250 },
    { o: '↪ fetching PR #42 diff via GitHub API', cls: 'out', d: 350 },
    { o: '✓ diff loaded · 4 files · 87 added lines', cls: 'ok', d: 250 },
    { o: '⚙ DiffFilter → 23 relevant lines', cls: 'label', d: 250 },
    { o: '⚙ SecretPreScan → 1 match · sk_live_…AbCd', cls: 'warn', d: 300 },
    { o: '⚙ LLMClient → openrouter:claude-opus-4-7', cls: 'label', d: 400 },
    { o: '⟳ analyzing... [▮▮▮▮▮▮▯▯▯▯]', cls: 'out', d: 500 },
    { o: '⟳ analyzing... [▮▮▮▮▮▮▮▮▮▯]', cls: 'out', d: 400 },
    { o: '✓ 3 findings · HIGH:2 · MED:1', cls: 'ok', d: 250 },
    { o: '⚙ FalsePositiveFilter → 3 kept · 0 dropped', cls: 'label', d: 250 },
    { o: '⚙ CommentPublisher → posting inline reviews...', cls: 'label', d: 350 },
    { o: '✓ review posted · github.com/acme/api/pull/42', cls: 'ok', d: 250 },
    { o: '✓ summary updated · 3 findings', cls: 'ok', d: 200 },
    { o: '◆ done in 4.21s · cost $0.018', cls: 'label', d: 150 }
  ];

  let termRun = false;
  async function runTerminal() {
    if (termRun) return;
    const term = document.getElementById('term');
    if (!term) return;
    termRun = true;
    term.innerHTML = '';
    for (const step of TERM_SCRIPT) {
      const line = document.createElement('div');
      line.className = 'line';
      if (step.p) {
        line.innerHTML = `<span class="prompt">${step.p}</span><span class="cmd"></span>`;
        term.appendChild(line);
        const cmd = line.querySelector('.cmd');
        await typeWord(cmd, step.t, 0);
      } else {
        line.innerHTML = `<span class="${step.cls || 'out'}">${step.o}</span>`;
        term.appendChild(line);
      }
      term.scrollTop = term.scrollHeight;
      await new Promise(r => setTimeout(r, step.d || 200));
    }
    // blinking cursor at end
    const cursor = document.createElement('span');
    cursor.className = 'cursor';
    term.appendChild(cursor);
  }

  // ---------- pipeline pulse animation (extra glow on nodes sequentially)
  function pulsePipeline() {
    const nodes = document.querySelectorAll('.pn');
    if (!nodes.length) return;
    let i = 0;
    const id = setInterval(() => {
      nodes.forEach(n => n.classList.remove('pulse'));
      const cur = nodes[i % nodes.length];
      cur.classList.add('pulse');
      i++;
    }, 700);
    return id;
  }

  // ---------- enter handlers
  let titleDone = false;
  let pipelineId = null;
  function onEnter(i, prev) {
    const s = slides[i];
    // title slide
    if (i === 0 && !titleDone) {
      titleDone = true;
      runTitleTyped().then(() => animateCountsIn(s));
    }
    // pipeline slide
    if (s.querySelector('.pipeline')) {
      if (pipelineId) { clearInterval(pipelineId); pipelineId = null; }
      pipelineId = pulsePipeline();
    } else if (pipelineId) {
      clearInterval(pipelineId); pipelineId = null;
    }
    // demo terminal
    if (s.querySelector('#term')) {
      runTerminal();
    }
  }

  // ---------- init
  setActive(0);
  onEnter(0, -1);

  // ---------- visibility: re-run typed on first paint
  if (current === 0 && !titleDone) {
    titleDone = true;
    runTitleTyped().then(() => animateCountsIn(slides[0]));
  }

  // expose for debugging
  window.__deck = { goto, next, prev, get current() { return current; } };
})();
