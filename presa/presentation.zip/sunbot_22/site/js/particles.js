/* =============================================================
   Particle network background — cyber/neural style
   - Nodes drift slowly, connect with lines when close
   - Pulses travel along connections
   - Mouse acts as repulsion + connection magnet
   ============================================================= */
(function () {
  const canvas = document.getElementById('bg-particles');
  const ctx = canvas.getContext('2d', { alpha: true });
  let DPR = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
  let W = 0, H = 0;
  const NODES = [];
  const PULSES = [];
  let NODE_COUNT = 90;
  const MAX_DIST = 150;
  const mouse = { x: -9999, y: -9999, active: false };

  function resize() {
    W = window.innerWidth; H = window.innerHeight;
    canvas.width = W * DPR; canvas.height = H * DPR;
    canvas.style.width = W + 'px'; canvas.style.height = H + 'px';
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    NODE_COUNT = Math.round((W * H) / 18000);
    NODE_COUNT = Math.max(60, Math.min(140, NODE_COUNT));
    initNodes();
  }

  function initNodes() {
    NODES.length = 0;
    for (let i = 0; i < NODE_COUNT; i++) {
      NODES.push({
        x: Math.random() * W,
        y: Math.random() * H,
        vx: (Math.random() - 0.5) * 0.25,
        vy: (Math.random() - 0.5) * 0.25,
        r: Math.random() * 1.6 + 0.4,
        hue: 188 + Math.random() * 30, // cyan-blue range
        phase: Math.random() * Math.PI * 2
      });
    }
  }

  function spawnPulse() {
    if (NODES.length < 2) return;
    const a = NODES[Math.floor(Math.random() * NODES.length)];
    const b = NODES[Math.floor(Math.random() * NODES.length)];
    if (a === b) return;
    PULSES.push({ a, b, t: 0, speed: 0.005 + Math.random() * 0.012 });
  }

  let pulseTimer = 0;
  let time = 0;

  function tick() {
    time += 0.016;
    pulseTimer++;
    if (pulseTimer > 35) { spawnPulse(); pulseTimer = 0; }

    ctx.clearRect(0, 0, W, H);

    // Update nodes
    for (let i = 0; i < NODES.length; i++) {
      const n = NODES[i];
      n.x += n.vx;
      n.y += n.vy;

      // Mouse repulsion
      if (mouse.active) {
        const dx = n.x - mouse.x, dy = n.y - mouse.y;
        const d2 = dx * dx + dy * dy;
        if (d2 < 22000) {
          const d = Math.sqrt(d2) || 1;
          const force = (1 - d / 150) * 0.6;
          n.vx += (dx / d) * force * 0.04;
          n.vy += (dy / d) * force * 0.04;
        }
      }

      // Friction
      n.vx *= 0.985; n.vy *= 0.985;
      // Small ambient drift
      n.vx += (Math.random() - 0.5) * 0.003;
      n.vy += (Math.random() - 0.5) * 0.003;
      // Wrap edges
      if (n.x < -10) n.x = W + 10;
      if (n.x > W + 10) n.x = -10;
      if (n.y < -10) n.y = H + 10;
      if (n.y > H + 10) n.y = -10;
    }

    // Draw connections
    for (let i = 0; i < NODES.length; i++) {
      const a = NODES[i];
      for (let j = i + 1; j < NODES.length; j++) {
        const b = NODES[j];
        const dx = a.x - b.x, dy = a.y - b.y;
        const d = Math.sqrt(dx * dx + dy * dy);
        if (d < MAX_DIST) {
          const alpha = (1 - d / MAX_DIST) * 0.35;
          ctx.strokeStyle = `rgba(0, 229, 255, ${alpha})`;
          ctx.lineWidth = 0.6;
          ctx.beginPath();
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(b.x, b.y);
          ctx.stroke();
        }
      }

      // Connection to mouse
      if (mouse.active) {
        const dx = a.x - mouse.x, dy = a.y - mouse.y;
        const d = Math.sqrt(dx * dx + dy * dy);
        if (d < 180) {
          const alpha = (1 - d / 180) * 0.6;
          ctx.strokeStyle = `rgba(0, 229, 255, ${alpha})`;
          ctx.lineWidth = 0.8;
          ctx.beginPath();
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(mouse.x, mouse.y);
          ctx.stroke();
        }
      }
    }

    // Draw nodes with pulse
    for (let i = 0; i < NODES.length; i++) {
      const n = NODES[i];
      const pulse = 0.5 + 0.5 * Math.sin(time * 2 + n.phase);
      const r = n.r + pulse * 0.7;
      // outer glow
      const g = ctx.createRadialGradient(n.x, n.y, 0, n.x, n.y, r * 4);
      g.addColorStop(0, `rgba(0, 229, 255, ${0.6 + pulse * 0.3})`);
      g.addColorStop(1, 'rgba(0, 229, 255, 0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(n.x, n.y, r * 4, 0, Math.PI * 2);
      ctx.fill();
      // core
      ctx.fillStyle = `rgba(180, 240, 255, ${0.85 + pulse * 0.15})`;
      ctx.beginPath();
      ctx.arc(n.x, n.y, r, 0, Math.PI * 2);
      ctx.fill();
    }

    // Draw pulses traveling between nodes
    for (let i = PULSES.length - 1; i >= 0; i--) {
      const p = PULSES[i];
      p.t += p.speed;
      if (p.t >= 1) { PULSES.splice(i, 1); continue; }
      const x = p.a.x + (p.b.x - p.a.x) * p.t;
      const y = p.a.y + (p.b.y - p.a.y) * p.t;
      // bright traveling dot
      ctx.fillStyle = `rgba(0, 229, 255, ${Math.sin(p.t * Math.PI) * 0.9})`;
      ctx.beginPath();
      ctx.arc(x, y, 2.4, 0, Math.PI * 2);
      ctx.fill();
      // tail glow
      const gg = ctx.createRadialGradient(x, y, 0, x, y, 14);
      gg.addColorStop(0, `rgba(0, 229, 255, ${Math.sin(p.t * Math.PI) * 0.5})`);
      gg.addColorStop(1, 'rgba(0, 229, 255, 0)');
      ctx.fillStyle = gg;
      ctx.beginPath();
      ctx.arc(x, y, 14, 0, Math.PI * 2);
      ctx.fill();
    }

    requestAnimationFrame(tick);
  }

  window.addEventListener('resize', resize);
  window.addEventListener('mousemove', (e) => {
    mouse.x = e.clientX; mouse.y = e.clientY; mouse.active = true;
  });
  window.addEventListener('mouseleave', () => { mouse.active = false; });

  resize();
  requestAnimationFrame(tick);
})();
